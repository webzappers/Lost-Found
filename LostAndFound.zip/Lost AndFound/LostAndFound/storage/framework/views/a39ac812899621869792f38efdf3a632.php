<a href="/">
    <img src="<?php echo e(asset('images/lnflogo.jpg')); ?>" alt="Logo" class="h-20 rounded-xl shadow-sm">
</a>

<?php /**PATH C:\webapp\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>