<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .iium-green { background-color: #006633; }
        .text-iium-green { color: #006633; }
        .bg-iium-green { background-color: #006633; }
    </style>

    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            
            <div class="relative overflow-hidden bg-white rounded-3xl shadow-lg mb-10 border border-gray-100">
                <div class="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-green-50 rounded-full opacity-50"></div>
                
                <div class="relative p-10 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div class="flex-1 text-center md:text-left">
                        <h1 class="text-4xl font-extrabold text-gray-900 leading-tight">
                            Lost something at <span class="text-iium-green">IIUM?</span>
                        </h1>
                        <p class="mt-4 text-sm text-gray-600 max-w-md font-medium mx-auto md:mx-0">
                            The official community portal to reunite students with their belongings. Fast, simple, and trusted.
                        </p>
                        <div class="mt-6 flex justify-center md:justify-start">
                            <a href="<?php echo e(route('items.create')); ?>" class="iium-green text-white px-8 py-3 rounded-xl font-bold hover:bg-green-800 transition transform hover:scale-105 shadow-lg flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                                Report Item
                            </a>
                        </div>
                    </div>

                    <div class="flex-shrink-0 flex items-center justify-center">
                        <img src="<?php echo e(asset('images/iiumlogo.png')); ?>" alt="Logo" class="h-32 w-auto">
                    </div>

                    <div class="flex-1 hidden md:block">
                        <div class="w-full h-40 bg-green-50 rounded-2xl flex items-center justify-center border-2 border-dashed border-green-200 text-green-600 font-black tracking-widest text-center px-4 leading-tight uppercase">
                            WEBZAPPER HUB:<br>REUNITING UMMAH
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="mb-6">
                <form action="<?php echo e(route('dashboard')); ?>" method="GET" class="flex flex-col md:flex-row gap-3">
                    <div class="flex-grow">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                               class="w-full border-gray-200 rounded-2xl py-3 px-5 text-sm focus:ring-iium-green focus:border-iium-green shadow-sm"
                               placeholder="Search for items, brands, or colors...">
                    </div>
                    <div class="md:w-1/4">
                        <input type="text" name="location" value="<?php echo e(request('location')); ?>"
                               class="w-full border-gray-200 rounded-2xl py-3 px-5 text-sm focus:ring-iium-green focus:border-iium-green shadow-sm"
                               placeholder="Location (e.g. Kulliyyah)...">
                    </div>
                    <button type="submit" class="iium-green text-white px-10 py-3 rounded-2xl font-bold text-sm hover:bg-green-800 transition shadow-md">
                        Search
                    </button>
                </form>
            </div>

            
            <div class="flex flex-col md:flex-row md:items-center justify-between mb-8">
                <div class="flex items-center space-x-2 bg-gray-200/50 p-1 rounded-2xl w-fit">
                    <a href="<?php echo e(route('dashboard')); ?>" 
                       class="px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all <?php echo e(!isset($currentType) ? 'bg-white text-iium-green shadow-sm' : 'text-gray-500 hover:text-gray-700'); ?>">
                        All
                    </a>
                    <a href="<?php echo e(route('items.lost')); ?>" 
                       class="px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all <?php echo e((isset($currentType) && $currentType == 'lost') ? 'bg-orange-500 text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'); ?>">
                        Lost
                    </a>
                    <a href="<?php echo e(route('items.found')); ?>" 
                       class="px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all <?php echo e((isset($currentType) && $currentType == 'found') ? 'bg-iium-green text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'); ?>">
                        Found
                    </a>
                </div>
                <p class="text-sm text-gray-400 font-bold mt-4 md:mt-0 uppercase tracking-widest">
                    Showing <?php echo e($items->count()); ?> Results
                </p>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 overflow-hidden group flex flex-col">
                        <div class="h-48 w-full bg-gray-100 relative overflow-hidden">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->image_path): ?>
                                <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>" class="w-full h-full object-cover transition duration-500 <?php echo e($item->status === 'claimed' ? 'brightness-[0.4]' : 'group-hover:scale-105'); ?>">
                            <?php else: ?>
                                <div class="flex items-center justify-center h-full text-gray-300 italic text-xs uppercase font-bold tracking-tighter">No Photo Provided</div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->status === 'claimed'): ?>
                                <div class="absolute inset-0 flex items-center justify-center">
                                    <span class="border-2 border-white text-white text-xs font-black uppercase px-4 py-1.5 rounded-lg rotate-[-12deg] tracking-[0.2em] shadow-2xl">
                                        Claimed
                                    </span>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <div class="absolute top-4 left-4">
                                <span class="text-[9px] font-black px-3 py-1.5 rounded-full shadow-md <?php echo e($item->type == 'lost' ? 'bg-orange-500 text-white' : 'bg-green-600 text-white'); ?>">
                                    <?php echo e(strtoupper($item->type)); ?>

                                </span>
                            </div>
                        </div>

                        <div class="p-6 flex flex-col flex-grow">
                            <h4 class="text-lg font-bold text-gray-900 uppercase truncate mb-1 <?php echo e($item->status === 'claimed' ? 'text-gray-400' : ''); ?>"><?php echo e($item->title); ?></h4>
                            <p class="text-xs text-gray-500 flex items-center mb-4">
                                <svg class="w-3 h-3 mr-1 text-iium-green" fill="currentColor" viewBox="0 0 20 20"><path d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"></path></svg>
                                <?php echo e($item->location); ?>

                            </p>
                            <div class="mt-auto">
                                <a href="<?php echo e(route('items.show', $item->id)); ?>" class="w-full text-center block <?php echo e($item->status === 'claimed' ? 'bg-gray-100 text-gray-400' : 'bg-gray-900 hover:bg-iium-green text-white'); ?> text-[10px] font-black uppercase tracking-widest py-3 rounded-xl transition shadow-md">
                                    <?php echo e($item->status === 'claimed' ? 'Case Closed' : 'View Details'); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div class="mt-12 border-t pt-12">
                <h2 class="text-2xl font-black text-gray-900 uppercase tracking-tight mb-8">Reporter Activity Hub</h2>
                
                <?php
                    $myReportedItems = \App\Models\Item::where('user_id', auth()->id())->with('claims.user')->latest()->get();
                ?>

                <div class="space-y-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $myReportedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden">
                            <div class="px-8 py-4 bg-gray-50 border-b flex justify-between items-center">
                                <span class="font-bold text-gray-700 uppercase text-sm"><?php echo e($myItem->title); ?></span>
                                <span class="text-[10px] font-black px-3 py-1 bg-white rounded-full border text-gray-400 uppercase"><?php echo e($myItem->status); ?></span>
                            </div>

                            <div class="p-8">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_2 = true; $__currentLoopData = $myItem->claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <div class="flex flex-col md:flex-row gap-6 p-6 rounded-3xl border border-gray-100 bg-white mb-4 shadow-sm">
                                        
                                        
                                        <div class="md:w-1/4">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($claim->proof_image_path)): ?>
                                                <a href="<?php echo e(asset('storage/' . $claim->proof_image_path)); ?>" target="_blank" class="block group">
                                                    <img src="<?php echo e(asset('storage/' . $claim->proof_image_path)); ?>" 
                                                         class="w-full h-32 object-cover rounded-2xl shadow-sm border-2 border-white group-hover:scale-[1.02] transition duration-300"
                                                         onerror="this.onerror=null;this.parentElement.innerHTML='<div class=\'w-full h-32 bg-red-50 rounded-2xl flex items-center justify-center text-red-400 text-[10px] font-bold\'>IMAGE NOT LINKED</div>';">
                                                    <p class="text-[8px] text-center text-gray-400 mt-2 font-black uppercase tracking-widest">Click to enlarge</p>
                                                </a>
                                            <?php else: ?>
                                                <div class="w-full h-32 bg-gray-50 rounded-2xl flex flex-col items-center justify-center text-gray-300 border-2 border-dashed border-gray-100">
                                                    <svg class="w-6 h-6 mb-1 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                                    <span class="text-[9px] font-black uppercase">No Photo Proof</span>
                                                </div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>

                                        
                                        <div class="md:w-3/4 flex flex-col justify-between">
                                            <div>
                                                <div class="flex justify-between items-start">
                                                    <p class="text-[11px] font-black text-[#006633] uppercase tracking-wider">Claimant: <?php echo e($claim->user->name); ?></p>
                                                    <span class="text-[9px] font-bold px-2 py-0.5 rounded <?php echo e($claim->status == 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'); ?> uppercase italic">
                                                        <?php echo e($claim->status); ?>

                                                    </span>
                                                </div>
                                                <div class="bg-gray-50 p-4 rounded-2xl mt-3 border border-gray-100">
                                                    <p class="text-sm text-gray-600 leading-relaxed italic">"<?php echo e($claim->proof_description); ?>"</p>
                                                </div>
                                            </div>

                                            <div class="mt-6 flex gap-3">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($claim->status === 'pending'): ?>
                                                    <form action="<?php echo e(route('claims.update', ['claim' => $claim->id, 'status' => 'approved'])); ?>" method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="bg-[#006633] text-white text-[10px] font-black uppercase px-8 py-3 rounded-xl hover:bg-green-800 transition shadow-sm">Approve</button>
                                                    </form>
                                                    <form action="<?php echo e(route('claims.update', ['claim' => $claim->id, 'status' => 'rejected'])); ?>" method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="border border-red-200 text-red-500 text-[10px] font-black uppercase px-8 py-3 rounded-xl hover:bg-red-50 transition">Reject</button>
                                                    </form>
                                                <?php else: ?>
                                                    <div class="flex items-center gap-2">
                                                        <span class="text-[10px] font-black uppercase px-4 py-2 rounded-lg <?php echo e($claim->status == 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                                                            Claim <?php echo e(ucfirst($claim->status)); ?>

                                                        </span>
                                                        <p class="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">Decision Finalized</p>
                                                    </div>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <p class="text-xs text-gray-400 font-bold uppercase text-center italic py-4">No incoming claims for this item</p>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-20 bg-white rounded-[2rem] border-2 border-dashed border-gray-100">
                            <svg class="mx-auto w-12 h-12 text-gray-200 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                            <p class="text-gray-400 font-bold uppercase tracking-widest text-xs">You haven't reported any items yet.</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\webapp\resources\views/dashboard.blade.php ENDPATH**/ ?>