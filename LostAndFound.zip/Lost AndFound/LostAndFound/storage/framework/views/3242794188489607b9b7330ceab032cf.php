<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-2xl mx-auto px-4">
            <h2 class="text-2xl font-black text-gray-900 mb-6 uppercase tracking-tight">Edit Report</h2>

            <form action="<?php echo e(route('items.update', $item->id)); ?>" method="POST" class="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 

                <div class="space-y-6">
                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Item Title</label>
                        <input type="text" name="title" value="<?php echo e(old('title', $item->title)); ?>" class="w-full border-gray-200 rounded-xl focus:ring-[#006633] focus:border-[#006633]">
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Type</label>
                        <select name="type" class="w-full border-gray-200 rounded-xl">
                            <option value="lost" <?php echo e($item->type == 'lost' ? 'selected' : ''); ?>>Lost</option>
                            <option value="found" <?php echo e($item->type == 'found' ? 'selected' : ''); ?>>Found</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Location</label>
                        <input type="text" name="location" value="<?php echo e(old('location', $item->location)); ?>" class="w-full border-gray-200 rounded-xl">
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Description</label>
                        <textarea name="description" rows="4" class="w-full border-gray-200 rounded-xl"><?php echo e(old('description', $item->description)); ?></textarea>
                    </div>

                    <button type="submit" class="w-full bg-[#006633] text-white font-black uppercase tracking-widest py-4 rounded-xl shadow-lg hover:bg-green-800 transition">
                        Update Report
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\webapp\resources\views/items/edit.blade.php ENDPATH**/ ?>