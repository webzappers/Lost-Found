<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-xl text-[#006633] leading-tight">My Activity Hub</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            
            <h3 class="text-lg font-bold text-gray-700 mb-6 flex items-center">
                <span class="bg-[#006633] w-2 h-6 rounded mr-2"></span> My Reported Items & Incoming Claims
            </h3>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($myItems) && $myItems->count() > 0): ?>
                <div class="grid grid-cols-1 gap-8 mb-12">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $myItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
                            
                            <div class="flex items-center justify-between border-b border-gray-50 pb-4 mb-4">
                                <div class="flex items-center">
                                    <div class="w-16 h-16 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0 border">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->image_path): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>" class="w-full h-full object-cover">
                                        <?php else: ?>
                                            <div class="w-full h-full flex items-center justify-center text-[8px] text-gray-400 font-bold uppercase">No Photo</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                    <div class="ml-4">
                                        <h4 class="font-black text-gray-900 text-base uppercase"><?php echo e($item->title); ?></h4>
                                        <p class="text-[10px] text-white bg-[#006633] px-3 py-0.5 rounded-full inline-block uppercase font-black tracking-tighter"><?php echo e($item->type); ?></p>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="bg-gray-50 rounded-[1.5rem] p-5">
                                <h5 class="text-[10px] font-black text-gray-400 uppercase mb-4 tracking-[0.2em]">Incoming Claims for this Item:</h5>
                                
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $item->claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="bg-white border border-gray-100 rounded-2xl p-5 mb-4 shadow-sm">
                                        <div class="flex flex-col md:flex-row gap-6">
                                            
                                            
                                            <div class="w-full md:w-32 h-32 flex-shrink-0">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($incoming->proof_image_path): ?>
                                                    <img src="<?php echo e(asset('storage/' . $incoming->proof_image_path)); ?>" 
                                                         class="w-full h-full object-cover rounded-xl border cursor-zoom-in hover:opacity-90 transition"
                                                         onclick="window.open(this.src)">
                                                <?php else: ?>
                                                    <div class="w-full h-full bg-gray-100 rounded-xl flex items-center justify-center text-[9px] text-gray-400 italic text-center p-2 border border-dashed">No Photo Proof</div>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>

                                            <div class="flex-1">
                                                <div class="flex justify-between items-start mb-2">
                                                    <span class="font-black text-sm text-gray-800"><?php echo e($incoming->user->name); ?></span>
                                                    <span class="text-[9px] font-bold uppercase px-2 py-0.5 rounded <?php echo e($incoming->status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'); ?>">
                                                        <?php echo e($incoming->status); ?>

                                                    </span>
                                                </div>
                                                <p class="text-xs text-gray-600 italic mb-4">"<?php echo e($incoming->message); ?>"</p>
                                                
                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($incoming->status === 'pending'): ?>
                                                    <div class="flex gap-2">
                                                        <form action="<?php echo e(route('claims.update', [$incoming->id, 'approved'])); ?>" method="POST">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                            <button class="bg-[#006633] text-white text-[9px] font-black py-2 px-4 rounded-lg hover:bg-green-800 transition uppercase tracking-widest">Approve</button>
                                                        </form>
                                                        <form action="<?php echo e(route('claims.update', [$incoming->id, 'rejected'])); ?>" method="POST">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                            <button class="bg-red-50 text-red-600 text-[9px] font-black py-2 px-4 rounded-lg hover:bg-red-100 transition uppercase tracking-widest">Reject</button>
                                                        </form>
                                                    </div>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($incoming->status === 'approved'): ?>
                                                    <div class="mt-2 p-3 bg-blue-50 rounded-xl border border-blue-100 flex items-center justify-between">
                                                        <span class="text-[10px] text-blue-800 font-bold uppercase"><?php echo e($incoming->user->email); ?></span>
                                                        <a href="mailto:<?php echo e($incoming->user->email); ?>" class="text-[10px] bg-blue-600 text-white px-3 py-1 rounded-md font-bold">Email Now</a>
                                                    </div>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-xs text-gray-400 italic text-center py-4">No claims have been submitted for this item yet.</p>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="bg-white p-12 text-center rounded-[2rem] border-2 border-dashed text-gray-400 mb-12">
                    You haven't reported any lost or found items yet.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <hr class="my-12 border-gray-200">

            
            <h3 class="text-lg font-bold text-gray-700 mb-6 flex items-center">
                <span class="bg-orange-500 w-2 h-6 rounded mr-2"></span> My Outgoing Claims (Sent to Others)
            </h3>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($myClaims) && $myClaims->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $myClaims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col justify-between">
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <h4 class="font-black text-gray-900 uppercase text-sm"><?php echo e($claim->item->title ?? 'Deleted Item'); ?></h4>
                                    <p class="text-[10px] font-bold <?php echo e($claim->status === 'approved' ? 'text-green-600' : 'text-blue-500'); ?> uppercase tracking-widest">
                                        Status: <?php echo e($claim->status); ?>

                                    </p>
                                </div>
                            </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($claim->status === 'approved' && $claim->item?->user): ?>
                                <div class="mt-2 p-4 bg-green-50 rounded-[1.5rem] border border-green-100">
                                    <p class="text-[9px] font-black text-green-800 uppercase mb-2">Claim Approved! Contact Finder:</p>
                                    <div class="flex items-center justify-between">
                                        <span class="text-[10px] text-gray-600 font-medium truncate mr-2"><?php echo e($claim->item->user->email); ?></span>
                                        <a href="mailto:<?php echo e($claim->item->user->email); ?>" class="bg-[#006633] text-white text-[9px] px-3 py-1.5 rounded-lg font-black uppercase transition hover:scale-105">
                                            Email
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="bg-white p-10 text-center rounded-[2rem] border border-dashed text-gray-400 text-sm">
                    You haven't sent any claims for lost items yet.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\webapp\resources\views/profile/my-items.blade.php ENDPATH**/ ?>