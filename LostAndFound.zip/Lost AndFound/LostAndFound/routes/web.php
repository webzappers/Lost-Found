<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\ClaimController;

Route::get('/', function () {
    return view('welcome');
});
    Route::get('/items/filter/lost', [ItemController::class, 'lost'])->name('items.lost');
    Route::get('/items/filter/found', [ItemController::class, 'found'])->name('items.found');
    Route::middleware(['auth:sanctum', config('jetstream.auth_session'), 'verified'])->group(function () {
        Route::get('/claim-item/{item}', [ClaimController::class, 'create'])->name('claims.create');
Route::post('/claim-item/store', [ClaimController::class, 'store'])->name('claims.store');
    Route::get('/dashboard', [ItemController::class, 'index'])->name('dashboard');
    Route::get('/items/create', [ItemController::class, 'create'])->name('items.create');
    Route::post('/items', [ItemController::class, 'store'])->name('items.store');
    Route::post('/items/{item}/claim', [ClaimController::class, 'store'])->name('claims.store');
    Route::get('/items/{item}/claim', [ClaimController::class, 'create'])->name('claims.create');
    Route::post('/items/{item}/claim', [ClaimController::class, 'store'])->name('claims.store');
    Route::patch('/claims/{claim}/{status}', [ClaimController::class, 'update'])->name('claims.update');
    Route::get('/claims/create', [ClaimController::class, 'create'])->name('claims.create');
    Route::post('/claims', [ClaimController::class, 'store'])->name('claims.store');
    Route::get('/profile/contact', function() {
        return view('profile.edit-contact');
    })->name('profile.contact.edit');
    Route::get('/dashboard', [ItemController::class, 'index'])->middleware(['auth'])->name('dashboard');
    Route::get('/dashboard', [ItemController::class, 'index'])->name('dashboard');
    Route::resource('items', ItemController::class);
    Route::get('/items/lost', [ItemController::class, 'lost'])->name('items.lost');
    Route::get('/items/found', [ItemController::class, 'found'])->name('items.found');
    Route::resource('items', ItemController::class);
    Route::post('/claims', [ClaimController::class, 'store'])->name('claims.store');
    Route::get('/my-activity', [ItemController::class, 'myItems'])->name('my.items');
    Route::delete('/items/{id}', [App\Http\Controllers\ItemController::class, 'destroy'])->name('items.destroy');
    Route::patch('/claims/{claim}/{status}', [ClaimController::class, 'update'])->name('claims.update');
    Route::patch('/profile/contact', [ProfileController::class, 'updateContact'])->name('profile.contact.update');
});