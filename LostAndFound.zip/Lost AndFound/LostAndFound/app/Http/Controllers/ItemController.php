<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Claim;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ItemController extends Controller
{
    public function index(Request $request) {
        $query = Item::query();

        if ($request->filled('search')) {
            $query->where('title', 'like', '%' . $request->search . '%')
                ->orWhere('description', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('location')) {
            $query->where('location', 'like', '%' . $request->location . '%');
        }

        $items = $query->latest()->get();
        return view('dashboard', compact('items'));
    }

    public function create() {
        return view('items.create');
    }

    public function store(Request $request){
        $request->validate([
            'title' => 'required|min:3|max:255',
            'description' => 'required|min:5',
            'type' => 'required',
            'location' => 'required',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Optional: validate image
        ]);
        $path = null;
        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('items', 'public');
        }

        Item::create([
            'user_id' => auth()->id(),
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'location' => $request->location,
            'image_path' => $path,
            'status' => 'open',
        ]);

        return redirect()->route('dashboard')->with('success', 'Item reported successfully!');
    }

    public function lost()
    {
        $items = \App\Models\Item::where('type', 'lost')->latest()->get();
        
        return view('dashboard', [
            'items' => $items,
            'currentType' => 'lost'
        ]);
    }

    public function found()
    {
        $items = \App\Models\Item::where('type', 'found')->latest()->get();
        
        return view('dashboard', [
            'items' => $items,
            'currentType' => 'found'
        ]);
    }
    public function show($id)
    {
        $item = \App\Models\Item::with('user')->findOrFail($id);

        return view('items.show', compact('item'));
    }

    public function myActivity() {
        $user = auth()->user();
    
        $myItems = Item::where('user_id', $user->id)->latest()->get();
        $myClaims = Claim::where('user_id', $user->id)->with('item')->latest()->get();

        return view('profile.my-items', [
            'myItems' => $myItems,
            'myClaims' => $myClaims
        ]);
    }

    public function destroy($id){
        $item = \App\Models\Item::findOrFail($id);

        if (auth()->id() !== $item->user_id) {
            return redirect()->route('dashboard')->with('error', 'You are not authorized to delete this.');
        }
        if ($item->image_path) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($item->image_path);
        }

        if ($item->user_id !== auth()->id()) {
            return abort(403, 'Unauthorized action.');
        }

        $item->delete();

        return redirect()->route('dashboard')->with('status', 'Item deleted successfully!');
        }
        public function edit($id)
        {
            $item = \App\Models\Item::findOrFail($id);

            if (auth()->id() !== $item->user_id) {
                return redirect()->route('dashboard')->with('error', 'Unauthorized access.');
            }

            return view('items.edit', compact('item'));
        }

        public function update(Request $request, $id)
        {
            $item = \App\Models\Item::findOrFail($id);

            if (auth()->id() !== $item->user_id) {
                return abort(403);
            }

            $validated = $request->validate([
                'title' => 'required|string|max:255',
                'description' => 'required|string',
                'location' => 'required|string',
                'type' => 'required|in:lost,found',
            ]);

            $item->update($validated);

            return redirect()->route('items.show', $item->id)->with('status', 'Item updated successfully!');
        }

        public function myItems()
        {
            $user = auth()->user();

            $myItems = \App\Models\Item::where('user_id', $user->id)
                ->with(['claims.user']) 
                ->latest()
                ->get();

            $myClaims = \App\Models\Claim::where('user_id', $user->id)
                ->with(['item.user'])
                ->latest()
                ->get();

            return view('profile.my-items', compact('myItems', 'myClaims'));
        }
}