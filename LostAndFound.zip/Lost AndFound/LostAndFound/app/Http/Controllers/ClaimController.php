<?php

namespace App\Http\Controllers;

use App\Models\Claim;
use App\Models\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClaimController extends Controller
{
    public function create(Item $item)
    {
        if ($item->user_id === auth()->id()) {
            return redirect()->route('dashboard')->with('error', 'You cannot claim your own item.');
        }

        return view('claims.create', compact('item'));
    }

    public function store(Request $request)
    {
        $item = \App\Models\Item::findOrFail($request->item_id);

        if ($item->status === 'claimed') {
            return redirect()->back()->with('error', 'Sorry, this item has already been claimed.');
        }

        $request->validate([
            'item_id' => 'required|exists:items,id',
            'proof_description' => 'required|string|min:5',
            'proof_image' => 'required|image|mimes:jpeg,png,jpg|max:5120', 
        ]);

        if ($request->hasFile('proof_image')) {
        $path = $request->file('proof_image')->store('claims', 'public');
    }

        Claim::create([
            'item_id' => $request->item_id,
            'user_id' => auth()->id(),
            'proof_description' => $request->proof_description,
            'proof_image_path' => $path, // Make sure this matches your DB column
            'status' => 'pending',
        ]);

        return redirect()->route('dashboard')->with('status', 'Claim request submitted successfully!');
    }

    public function update(Request $request, $id, $status)
    {
        $claim = \App\Models\Claim::findOrFail($id);
        
        // Ensure only the person who found the item can approve/reject
        if ($claim->item->user_id !== auth()->id()) {
            return back()->with('error', 'Unauthorized action.');
        }

        $claim->status = $status; 
        $claim->save();

        if ($status === 'approved') {
            $item = $claim->item;
            $item->status = 'claimed'; 
            $item->save();

            // Optional: Automatically reject all other pending claims for this item
            \App\Models\Claim::where('item_id', $item->id)
                ->where('id', '!=', $claim->id)
                ->update(['status' => 'rejected']);
        }

        return back()->with('status', 'Action processed successfully!');
    }
}