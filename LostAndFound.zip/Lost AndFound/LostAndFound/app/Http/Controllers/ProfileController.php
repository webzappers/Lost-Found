<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request; 
use App\Models\User;

class ItemController extends Controller {
    public function updateContact(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'phone_number' => 'nullable|string|max:20',
        'identifier_id' => 'nullable|string|max:50',
    ]);

    $user = auth()->user();
    $user->update([
        'name' => $request->name,
        'phone_number' => $request->phone_number,
        'identifier_id' => $request->identifier_id,
    ]);

    return back()->with('success', 'Contact information updated!');
}
}
