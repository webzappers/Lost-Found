<x-app-layout>
    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            
            {{-- Back Link --}}
            <div class="mb-6">
                <a href="{{ route('items.show', $item->id) }}" class="text-gray-500 hover:text-[#006633] font-bold text-sm flex items-center transition">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    Back to Item Details
                </a>
            </div>

            <div class="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
                <div class="p-8 md:p-12">
                    <h2 class="text-3xl font-black text-gray-900 uppercase tracking-tight mb-2">Claim Item</h2>
                    <p class="text-gray-500 font-medium mb-8">Please provide specific details to prove this item belongs to you.</p>

                    {{-- Item Summary Card --}}
                    <div class="mb-8 p-4 bg-gray-50 rounded-2xl flex items-center border border-gray-100">
                        @if($item->image_path)
                            <img src="{{ asset('storage/' . $item->image_path) }}" class="w-20 h-20 rounded-xl object-cover shadow-sm mr-4">
                        @endif
                        <div>
                            <span class="text-[10px] font-black text-[#006633] uppercase tracking-widest">You are claiming:</span>
                            <h4 class="text-lg font-bold text-gray-900">{{ $item->title }}</h4>
                        </div>
                    </div>

                    {{-- Claim Form --}}
                    <form action="{{ route('claims.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="item_id" value="{{ $item->id }}">

                        <div class="mb-6">
                            <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-3">Proof Description</label>
                            <textarea name="proof_description" rows="4" required 
                                class="w-full border-gray-200 rounded-2xl focus:ring-[#006633] focus:border-[#006633] text-sm" 
                                placeholder="Describe unique features, what's inside, or where you lost it...">{{ old('proof_description') }}</textarea>
                        </div>

                        <div class="mb-8">
                            <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-3">Upload Photo Proof (Required)</label>
                            
                            {{-- Interactive Upload Box --}}
                            <div class="relative group">
                                <div id="dropzone" class="border-2 border-dashed border-gray-200 rounded-[2rem] p-8 text-center hover:border-[#006633] hover:bg-green-50/30 transition-all cursor-pointer bg-gray-50/50">
                                    <input type="file" name="proof_image" id="proof_image" accept="image/*" required class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                    
                                    {{-- Placeholder State --}}
                                    <div id="placeholder-content">
                                        <div class="bg-white w-16 h-16 rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                                            <svg class="w-8 h-8 text-[#006633]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                            </svg>
                                        </div>
                                        <p class="text-sm font-bold text-gray-700">Click or Drag Photo Here</p>
                                        <p class="text-[10px] text-gray-400 uppercase font-black tracking-widest mt-1">PNG, JPG up to 5MB</p>
                                    </div>

                                    {{-- Preview State (Hidden by default) --}}
                                    <div id="preview-container" class="hidden">
                                        <img id="image-preview" src="#" class="mx-auto max-h-48 rounded-2xl shadow-md border-4 border-white mb-3">
                                        <p class="text-xs font-bold text-[#006633]">Photo selected! Click to change.</p>
                                    </div>
                                </div>
                            </div>
                            
                            @error('proof_image')
                                <p class="text-red-500 text-xs mt-3 font-bold">{{ $message }}</p>
                            @enderror
                        </div>

                        <button type="submit" class="w-full bg-[#006633] text-white font-black uppercase tracking-widest py-4 rounded-2xl shadow-lg hover:bg-green-800 hover:scale-[1.02] transform transition active:scale-95">
                            Submit Claim Request
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- JavaScript for Live Preview --}}
    <script>
        const imageInput = document.getElementById('proof_image');
        const previewContainer = document.getElementById('preview-container');
        const placeholderContent = document.getElementById('placeholder-content');
        const imagePreview = document.getElementById('image-preview');

        imageInput.onchange = evt => {
            const [file] = imageInput.files;
            if (file) {
                // Show the preview and hide the placeholder
                placeholderContent.classList.add('hidden');
                previewContainer.classList.remove('hidden');
                
                // Set the image source
                imagePreview.src = URL.createObjectURL(file);
            }
        }
    </script>
</x-app-layout>