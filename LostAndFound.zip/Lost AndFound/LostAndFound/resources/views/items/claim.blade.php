<x-app-layout>
    <div class="py-12">
        <div class="max-w-2xl mx-auto bg-white p-8 rounded-3xl shadow-lg border border-gray-100">
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Claim This Item</h2>
                <p class="text-sm text-gray-500 italic">Item: <span class="font-bold text-green-700">{{ $item->title }}</span></p>
                <p class="text-xs text-gray-400 mt-2">Please provide proof that this item belongs to you.</p>
            </div>

            <form action="{{ route('claims.store', $item->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="space-y-5">
                    
                    {{-- Ownership Description --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Proof of Ownership (Description)</label>
                        <textarea name="message" rows="4" 
                                  placeholder="Describe details only the owner would know (e.g., unique scratches, serial numbers, specific contents inside, or what the lockscreen wallpaper is)..." 
                                  class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600 @error('message') border-red-500 @enderror" required>{{ old('message') }}</textarea>
                        @error('message')
                            <p class="text-red-500 text-xs mt-1 font-semibold">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Proof Image Upload --}}
                    <div class="border-2 border-dashed border-gray-200 rounded-2xl p-6 text-center hover:border-green-400 transition">
                        <label class="block text-sm font-bold text-gray-700 mb-2">
                            Upload Proof Photo <span class="text-red-500">*</span>
                        </label>
                        
                        <input type="file" name="claim_image" required 
                            class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100">
                        
                        <p class="text-[10px] text-red-400 mt-2 font-bold uppercase">This field is required to verify ownership.</p>
                        
                        @error('claim_image')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="pt-4 flex items-center justify-end space-x-3">
                        <a href="{{ url()->previous() }}" class="text-gray-500 font-bold px-6">Cancel</a>
                        <button type="submit" class="bg-green-700 hover:bg-green-800 text-white px-8 py-3 rounded-xl font-bold shadow-lg transition transform hover:scale-[1.01]">
                            Submit Claim
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</x-app-layout>