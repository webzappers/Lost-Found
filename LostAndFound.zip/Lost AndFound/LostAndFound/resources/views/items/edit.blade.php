<x-app-layout>
    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-2xl mx-auto px-4">
            <h2 class="text-2xl font-black text-gray-900 mb-6 uppercase tracking-tight">Edit Report</h2>

            <form action="{{ route('items.update', $item->id) }}" method="POST" class="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
                @csrf
                @method('PUT') {{-- This is CRITICAL for updates --}}

                <div class="space-y-6">
                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Item Title</label>
                        <input type="text" name="title" value="{{ old('title', $item->title) }}" class="w-full border-gray-200 rounded-xl focus:ring-[#006633] focus:border-[#006633]">
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Type</label>
                        <select name="type" class="w-full border-gray-200 rounded-xl">
                            <option value="lost" {{ $item->type == 'lost' ? 'selected' : '' }}>Lost</option>
                            <option value="found" {{ $item->type == 'found' ? 'selected' : '' }}>Found</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Location</label>
                        <input type="text" name="location" value="{{ old('location', $item->location) }}" class="w-full border-gray-200 rounded-xl">
                    </div>

                    <div>
                        <label class="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Description</label>
                        <textarea name="description" rows="4" class="w-full border-gray-200 rounded-xl">{{ old('description', $item->description) }}</textarea>
                    </div>

                    <button type="submit" class="w-full bg-[#006633] text-white font-black uppercase tracking-widest py-4 rounded-xl shadow-lg hover:bg-green-800 transition">
                        Update Report
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>