<x-app-layout>
    <div class="py-12 bg-[#F8FAFC] min-h-screen">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            
            {{-- Back Button --}}
            <div class="mb-6">
                <a href="{{ route('dashboard') }}" class="text-gray-500 hover:text-[#006633] font-bold text-sm flex items-center transition">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    Back to Dashboard
                </a>
            </div>

            <div class="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
                <div class="flex flex-col md:flex-row">
                    
                    {{-- Left: Image Section --}}
                    <div class="md:w-1/2 bg-gray-50 relative">
                        @if($item->image_path)
                            <img src="{{ asset('storage/' . $item->image_path) }}" class="w-full h-full object-cover min-h-[400px]">
                        @else
                            <div class="flex flex-col items-center justify-center h-full min-h-[400px] text-gray-300">
                                <svg class="w-20 h-20 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                <span class="font-black uppercase tracking-widest text-xs">No Image Available</span>
                            </div>
                        @endif

                        <div class="absolute top-6 left-6 flex flex-col gap-2">
                            <span class="px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg {{ $item->type == 'lost' ? 'bg-orange-500 text-white' : 'bg-[#006633] text-white' }}">
                                {{ $item->type }} ITEM
                            </span>
                            @if($item->status === 'claimed')
                                <span class="px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg bg-gray-900 text-white">
                                    CASE CLOSED
                                </span>
                            @endif
                        </div>
                    </div>

                    {{-- Right: Details Section --}}
                    <div class="md:w-1/2 p-10">
                        <div class="mb-6">
                            <h2 class="text-3xl font-black text-gray-900 uppercase tracking-tight mb-2">{{ $item->title }}</h2>
                            <p class="text-[#006633] font-bold flex items-center">
                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"></path></svg>
                                {{ $item->location }}
                            </p>
                        </div>

                        <div class="space-y-6">
                            <div>
                                <h4 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Description</h4>
                                <p class="text-gray-600 leading-relaxed">{{ $item->description }}</p>
                            </div>

                            <div class="grid grid-cols-2 gap-4 pt-6 border-t border-gray-100">
                                <div>
                                    <h4 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Reported By</h4>
                                    <p class="text-sm font-bold text-gray-800">{{ $item->user->name }}</p>
                                </div>
                                <div>
                                    <h4 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Date Reported</h4>
                                    <p class="text-sm font-bold text-gray-800">{{ $item->created_at->format('M d, Y') }}</p>
                                </div>
                            </div>

                            {{-- Actions --}}
                            <div class="pt-8">
                                @if($item->status === 'claimed')
                                    <div class="w-full bg-gray-100 text-gray-400 font-black text-center py-4 rounded-2xl uppercase tracking-widest cursor-not-allowed border-2 border-dashed border-gray-200">
                                        Item Already Claimed
                                    </div>
                                @elseif(auth()->id() !== $item->user_id)
                                    {{-- Check if user already submitted a claim --}}
                                    @php
                                        $existingClaim = \App\Models\Claim::where('item_id', $item->id)->where('user_id', auth()->id())->first();
                                    @endphp

                                    @if($existingClaim)
                                        <div class="w-full bg-blue-50 text-blue-600 font-black text-center py-4 rounded-2xl uppercase tracking-widest border-2 border-blue-100">
                                            Claim Pending Review
                                        </div>
                                    @else
                                        <a href="{{ route('claims.create', $item->id) }}" 
                                        class="w-full text-center block bg-[#006633] hover:bg-green-800 text-white font-black uppercase tracking-widest py-4 rounded-2xl shadow-lg transition transform hover:-translate-y-1">
                                            Claim This Item
                                        </a>
                                    @endif
                                @else
                                    {{-- Owner Actions --}}
                                    <div class="flex space-x-3">
                                        <a href="{{ route('items.edit', $item->id) }}" class="flex-1 text-center border-2 border-gray-200 text-gray-600 font-black uppercase tracking-widest py-3 rounded-2xl hover:bg-gray-50 transition">
                                            Edit
                                        </a>
                                        <form action="{{ route('items.destroy', $item->id) }}" method="POST" class="flex-1" onsubmit="return confirm('Are you sure you want to delete this report?');">
                                            @csrf @method('DELETE')
                                            <button class="w-full border-2 border-red-100 text-red-500 font-black uppercase tracking-widest py-3 rounded-2xl hover:bg-red-50 transition">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                    <p class="text-[10px] text-gray-400 text-center mt-4 italic uppercase font-bold tracking-tighter">You reported this item</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>