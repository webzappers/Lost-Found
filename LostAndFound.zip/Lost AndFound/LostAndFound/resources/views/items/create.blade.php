<x-app-layout>
    <div class="py-12">
        <div class="max-w-2xl mx-auto bg-white p-8 rounded-3xl shadow-lg border border-gray-100">
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Report an Item</h2>
                <p class="text-sm text-gray-500">Please provide accurate details to help others identify the item.</p>
            </div>

            <form action="{{ route('items.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="space-y-5">
                    
                    {{-- Item Title --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Item Name</label>
                        <input type="text" name="title" value="{{ old('title') }}" 
                               placeholder="e.g., Blue Tumbler, Toyota Key" 
                               class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600 @error('title') border-red-500 @enderror" required>
                        @error('title')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Type Selection --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Report Type</label>
                        <select name="type" class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600">
                            <option value="lost" {{ old('type') == 'lost' ? 'selected' : '' }}>Lost (I lost this)</option>
                            <option value="found" {{ old('type') == 'found' ? 'selected' : '' }}>Found (I found this)</option>
                        </select>
                    </div>

                    {{-- Location --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Location</label>
                        <input type="text" name="location" value="{{ old('location') }}" 
                               placeholder="e.g., Kulliyyah of Engineering, Cafe" 
                               class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600 @error('location') border-red-500 @enderror" required>
                        @error('location')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                    
                    {{-- Description --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Detailed Description</label>
                        <textarea name="description" rows="4" 
                                  placeholder="Provide unique details (marks, stickers, brand, color)..." 
                                  class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600 @error('description') border-red-500 @enderror" required>{{ old('description') }}</textarea>
                        @error('description')
                            <p class="text-red-500 text-xs mt-1 font-semibold">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- Image Upload --}}
                    <div class="border-2 border-dashed border-gray-200 rounded-2xl p-6 text-center hover:border-green-400 transition">
                        <label class="block text-sm font-bold text-gray-700 mb-2">Upload Photo (Optional)</label>
                        <input type="file" name="image" class="w-full text-sm text-gray-500
                            file:mr-4 file:py-2 file:px-4
                            file:rounded-full file:border-0
                            file:text-sm file:font-semibold
                            file:bg-green-50 file:text-green-700
                            hover:file:bg-green-100">
                        @error('image')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="pt-4">
                        <button type="submit" class="w-full bg-green-700 hover:bg-green-800 text-white py-3 rounded-xl font-bold shadow-lg transition transform hover:scale-[1.01]">
                            Submit Report
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</x-app-layout>