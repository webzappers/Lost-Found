<x-app-layout>
    <div class="py-12">
        <div class="max-w-2xl mx-auto bg-white p-8 rounded-3xl shadow-lg border border-gray-100">
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Profile Management</h2>
                <p class="text-sm text-gray-500">Update your contact details so others can reach you regarding items.</p>
            </div>

            <form action="{{ route('profile.contact.update') }}" method="POST">
                @csrf
                @method('PATCH')

                <div class="space-y-5">
                    {{-- Name (Read Only or Editable) --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                        <input type="text" name="name" value="{{ auth()->user()->name }}" 
                               class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600">
                    </div>

                    {{-- Matric / ID Number --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Student/Staff ID</label>
                        <input type="text" name="identifier_id" value="{{ auth()->user()->identifier_id }}" 
                               placeholder="e.g., 211xxxx"
                               class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600">
                    </div>

                    {{-- Phone Number --}}
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">WhatsApp / Phone Number</label>
                        <input type="text" name="phone_number" value="{{ auth()->user()->phone_number }}" 
                               placeholder="e.g., +60123456789"
                               class="w-full rounded-xl border-gray-300 focus:ring-green-600 focus:border-green-600">
                        <p class="text-[10px] text-gray-400 mt-1">Include country code for easier WhatsApp clicking.</p>
                    </div>

                    <div class="pt-4">
                        <button type="submit" class="w-full bg-green-700 hover:bg-green-800 text-white py-3 rounded-xl font-bold shadow-lg transition">
                            Save Profile Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>