@props(['disabled' => false])

<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'border-gray-300 focus:border-[#006633] focus:ring-[#006633] rounded-md shadow-sm']) !!}>