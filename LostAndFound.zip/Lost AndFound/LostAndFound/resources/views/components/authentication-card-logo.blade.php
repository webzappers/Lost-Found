<a href="/">
    <img src="{{ asset('images/lnflogo.jpg') }}" alt="Logo" class="h-20 rounded-xl shadow-sm">
</a>

