<nav x-data="{ open: false }" class="bg-gradient-to-r from-[#006633] to-[#004d26] border-b border-[#00331a] shadow-2xl sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}" class="transform transition-transform duration-300 hover:scale-110">
                        <img src="{{ asset('images/lnflogo.jpg') }}" alt="Logo" class="block h-10 w-auto rounded-xl shadow-lg border border-green-400/30">
                    </a>
                </div>

                <div class="hidden space-x-6 sm:-my-px sm:ms-10 sm:flex">
                    <x-nav-link href="{{ route('dashboard') }}" :active="request()->routeIs('dashboard')" class="transition-all duration-300 ease-in-out">
                        {{ __('Dashboard') }}
                    </x-nav-link>
                    <x-nav-link href="{{ route('my.items') }}" :active="request()->routeIs('my.items')" class="transition-all duration-300 ease-in-out">
                        {{ __('My Activity') }}
                    </x-nav-link>
                    <x-nav-link href="{{ route('items.lost') }}" :active="request()->routeIs('items.lost')" class="transition-all duration-300 ease-in-out">
                        {{ __('Lost Items') }}
                    </x-nav-link>
                    <x-nav-link href="{{ route('items.found') }}" :active="request()->routeIs('items.found')" class="transition-all duration-300 ease-in-out">
                        {{ __('Found Items') }}
                    </x-nav-link>
                </div>
            </div>

            <div class="hidden sm:flex sm:items-center">
                <div class="ms-3 relative">
                    <x-dropdown align="right" width="48">
                        <x-slot name="trigger">
                            <span class="inline-flex rounded-md">
                                <button type="button" class="inline-flex items-center px-4 py-2 border border-green-400/20 text-sm leading-4 font-bold rounded-xl text-white bg-white/10 backdrop-blur-md hover:bg-white/20 focus:outline-none transition-all duration-300 ease-in-out shadow-sm">
                                    <div class="flex items-center">
                                        <div class="h-2 w-2 bg-green-400 rounded-full animate-pulse me-2"></div>
                                        {{ Auth::user()->name }}
                                    </div>
                                    <svg class="ms-2 -me-0.5 h-4 w-4 text-white/70" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                                    </svg>
                                </button>
                            </span>
                        </x-slot>

                        <x-slot name="content">
                            <div class="block px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">User Account</div>
                            <x-dropdown-link href="{{ route('profile.show') }}" class="hover:bg-green-50 transition-colors duration-200">Profile</x-dropdown-link>
                            <div class="border-t border-gray-100"></div>
                            <form method="POST" action="{{ route('logout') }}" x-data>
                                @csrf
                                <x-dropdown-link href="{{ route('logout') }}" @click.prevent="$root.submit();" class="hover:bg-red-50 hover:text-red-600 transition-colors duration-200">
                                    Log Out
                                </x-dropdown-link>
                            </form>
                        </x-slot>
                    </x-dropdown>
                </div>
            </div>

            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-xl text-white hover:bg-white/10 focus:outline-none transition-all duration-300">
                    <svg class="h-6 w-6 transform transition-transform duration-500" :class="{'rotate-180': open}" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <div x-show="open" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 -translate-y-4"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 translate-y-0"
         x-transition:leave-end="opacity-0 -translate-y-4"
         class="sm:hidden bg-white/95 backdrop-blur-xl border-t border-gray-100 shadow-2xl">
        <div class="pt-2 pb-3 space-y-1">
            <x-responsive-nav-link href="{{ route('dashboard') }}" :active="request()->routeIs('dashboard')">Dashboard</x-responsive-nav-link>
            <x-responsive-nav-link href="{{ route('my.items') }}" :active="request()->routeIs('my.items')">My Activity</x-responsive-nav-link>
            <x-responsive-nav-link href="{{ route('items.lost') }}" :active="request()->routeIs('items.lost')">Lost Items</x-responsive-nav-link>
            <x-responsive-nav-link href="{{ route('items.found') }}" :active="request()->routeIs('items.found')">Found Items</x-responsive-nav-link>
        </div>

        <div class="pt-4 pb-1 border-t border-gray-100 bg-gray-50/50">
            <div class="flex items-center px-4">
                <div class="flex-shrink-0 bg-[#006633] h-10 w-10 rounded-full flex items-center justify-center text-white font-bold">
                    {{ substr(Auth::user()->name, 0, 1) }}
                </div>
                <div class="ms-3">
                    <div class="font-bold text-base text-gray-800">{{ Auth::user()->name }}</div>
                    <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
                </div>
            </div>
            <div class="mt-3 space-y-1">
                <x-responsive-nav-link href="{{ route('profile.show') }}">Profile</x-responsive-nav-link>
                <form method="POST" action="{{ route('logout') }}" x-data>
                    @csrf
                    <x-responsive-nav-link href="{{ route('logout') }}" @click.prevent="$root.submit();">Log Out</x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>